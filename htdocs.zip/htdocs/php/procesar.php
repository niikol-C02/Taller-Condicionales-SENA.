<?php
// Validamos que los datos hayan sido enviados por el método POST
if (isset($_POST['comprobar'])) {
    $puntaje = $_POST['dato'];
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Resultado de Categorización</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <div class="container">
            <h1>Resultado del Rango</h1>
            <div class="resultado-box">
                <?php
                // Evaluación con Switch solicitada en el Reto B
                switch ($puntaje) {
                    case "1":
                        echo "<p class='categoria'>Rango: <strong>Principiante</strong></p>";
                        break;
                    case "2":
                        echo "<p class='categoria'>Rango: <strong>Pro</strong></p>";
                        break;
                    case "3":
                        echo "<p class='categoria'>Rango: <strong>Maestro</strong></p>";
                        break;
                    default:
                        echo "<p class='error'>Puntaje no válido.</p>";
                        break;
                }
                ?>
            </div>
            <a href="index.html" class="btn-regresar">Volver a intentar</a>
        </div>

    </body>
    </html>
    <?php
} else {
    // Si alguien intenta ingresar directamente a procesar.php sin usar el formulario, lo redirige al index.html
    header("Location: index.html");
    exit();
}
?>