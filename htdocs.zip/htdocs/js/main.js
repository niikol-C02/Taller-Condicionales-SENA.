const edadUsuario = Number(prompt("Ingresa tu edad"));

const mensaje = document.getElementById("resultado");

if (edadUsuario >= 18) {
    mensaje.innerHTML =
        "<h1 class='permitido'>Acceso permitido. ¡Bienvenido!</h1>";
} else {
    mensaje.innerHTML =
        "<h1 class='rechazado'>Acceso denegado. Debes ser mayor de edad.</h1>";
}